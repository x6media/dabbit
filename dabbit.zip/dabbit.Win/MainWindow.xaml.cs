﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media.Imaging;
using dabbit.Base;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace dabbit.Win
{

    [ComVisible(true)]
    public class JScriptBridge
    {
        private WebBrowser browser;

        public JScriptBridge(WebBrowser sender)
        {
            this.browser = sender;
        }

        public event OverlayVisible OnOverlayVisible;
        public event OverlayHide OnOverlayHide;

        public void OverlayVisible()
        {
            if (this.OnOverlayVisible != null)
            {
                this.OnOverlayVisible(this.browser);
            }
        }
        public void OverlayHide()
        {
            if (this.OnOverlayHide != null)
            {
                this.OnOverlayHide(this.browser);
            }
        }

    }
    public delegate void OverlayVisible(object sender);

    public delegate void OverlayHide(object sender);

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {



        enum IconTypes
        {
            None,
            Online,
            Offline,
            Away
        }
        //Connection cn = new Connection(new DabbitContext(), "localhost", 667, false);
        private TreeViewItem CreateTreeViewItem(string header, IconTypes icon)
        {

            TreeViewItem child = new TreeViewItem();
            StackPanel pan = new StackPanel();

            if (icon != IconTypes.None)
            {

                pan.Orientation = Orientation.Horizontal;

                Image image = new Image();
                image.Height = 16;

                switch (icon)
                {
                    case IconTypes.Offline:
                        image.Source = offlinePng.Frames[0];
                        break;
                    case IconTypes.Online:
                        image.Source = onlinePng.Frames[0];
                        break;
                    case IconTypes.Away:
                        image.Source = awayPng.Frames[0];
                        break;
                }
                
                pan.Children.Add(image);
            }

            pan.Children.Add(new TextBlock(new Run("  " + header)));
            child.Header = pan;
            return child;
        }


        public void OverlayHide(object sender)
        {
            WebBrowser sndr = sender as WebBrowser;

            foreach (WebBrowser br in CenterGrid.Children)
            {
                if (br != sndr)
                {
                    br.InvokeScript("toggleOverlay", new object[] { true });
                }
            }
        }


        public void OverlayVisible(object sender)
        {
        }

        JScriptBridge jsb;
        JScriptBridge jsb2;
        JScriptBridge jsb3;


        public MainWindow()
        {
            InitializeComponent();

            // Load Images into a cache.
            Stream awayStream = Assembly.GetEntryAssembly().GetManifestResourceStream("dabbit.Win.Assets.orb-away.png");
            this.awayPng = new PngBitmapDecoder(awayStream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);

            awayStream = Assembly.GetEntryAssembly().GetManifestResourceStream("dabbit.Win.Assets.orb-offline.png");
            this.offlinePng = new PngBitmapDecoder(awayStream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);

            awayStream = Assembly.GetEntryAssembly().GetManifestResourceStream("dabbit.Win.Assets.orb-online.png");
            this.onlinePng = new PngBitmapDecoder(awayStream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);

            TreeViewItem tvi = CreateTreeViewItem("Settings", IconTypes.None);


            Stream docStream = Assembly.GetEntryAssembly().GetManifestResourceStream("dabbit.Win.Assets.HTML.ChatPage.html");
            brows.NavigateToStream(docStream);



            docStream = Assembly.GetEntryAssembly().GetManifestResourceStream("dabbit.Win.Assets.HTML.ChatPage.html");
            browsb.NavigateToStream(docStream);
            docStream = Assembly.GetEntryAssembly().GetManifestResourceStream("dabbit.Win.Assets.HTML.ChatPage.html");
            browsc.NavigateToStream(docStream);


            jsb = new JScriptBridge(browsc);
            jsb.OnOverlayVisible += this.OverlayVisible;
            jsb.OnOverlayHide += this.OverlayHide;

            brows.ObjectForScripting = jsb;

            jsb2 = new JScriptBridge(browsc);
            jsb2.OnOverlayVisible += this.OverlayVisible;
            jsb2.OnOverlayHide += this.OverlayHide;

            browsc.ObjectForScripting = jsb2;
            
            jsb3 = new JScriptBridge(browsb);
            jsb3.OnOverlayVisible += this.OverlayVisible;
            jsb3.OnOverlayHide += this.OverlayHide;

            browsb.ObjectForScripting = jsb3;

            treeViewServerList.Items.Add(tvi);
            MultiSelect.AllowMultiSelection(treeViewServerList);

            //ctx.Servers.Add(new Server(ctx, new User() { Nick = "dabbit", Ident = "dabitp", Name = "David" }, new Connection(ctx, new WinSocket("localhost", 6667, false))));
            //ctx.Servers[0].OnRawMessage += MainWindow_OnRawMessage;

            
        }

        void MainWindow_OnRawMessage(object sender, Message e)
        {
            
        }


        private void dabbitLogo_Loaded(object sender, RoutedEventArgs e)
        {
            System.Reflection.Assembly thisExe;
            thisExe = System.Reflection.Assembly.GetExecutingAssembly();
            System.IO.Stream file = thisExe.GetManifestResourceStream("dabbit.Win.Assets.logo.png");

            // ... Create a new BitmapImage.
            BitmapImage b = new BitmapImage();
            b.BeginInit();
            b.StreamSource = file;
            b.EndInit();

            // ... Get Image reference from sender.
            var image = sender as Image;
            // ... Assign Source.
            image.Source = b;
        }



        PngBitmapDecoder awayPng;
        PngBitmapDecoder offlinePng;
        PngBitmapDecoder onlinePng;

        WinContext ctx = new WinContext();

        private void TextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                //brows.InvokeScript("addLine", new object[] { "notice", "& dab", "#FF0000", textInput.Text });
                browsb.InvokeScript("addLine", new object[] { "notice", "& dab", "#FF0000", textInput.Text });
                browsc.InvokeScript("addLine", new object[] { "notice", "& dab", "#FF0000", textInput.Text });
                textInput.Text = "";
            }


        }
    }



}
