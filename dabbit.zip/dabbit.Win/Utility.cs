﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace dabbit.Base
{

    public static class StringUtility
    {
        public static string ToMd5(this string me)
        {
            byte[] bytePassword = Encoding.UTF8.GetBytes(me);

            using (MD5 md5 = MD5.Create())
            {
                byte[] byteHashedPassword = md5.ComputeHash(bytePassword);
                return BitConverter.ToString(byteHashedPassword).Replace("-", "");
            }
        }
    }
}
